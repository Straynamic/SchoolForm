﻿//Jesse Clem
//Homework 4
//5/4/2018
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS266_Project
{
    public partial class Courses : Form
    {
        public Courses()
        {
            InitializeComponent();
        }

        private void SetReadyLabel(string value)
        {
            //create refrence to parent form
            MainForm parent = (MainForm)this.MdiParent;
            //assign value to ready label
            parent.ReadyLabel = value;
        }



        private void tblCoursesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tblCoursesBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.registrationDataSet);
                SetReadyLabel("Data saved sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error"); // if ant problems saving database, show user error info
                SetReadyLabel("Error saving data");
            }

        }

        private void Courses_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registrationDataSet.tblCourses' table. You can move, or remove it, as needed.
            try
            {
                this.tblCoursesTableAdapter.Fill(this.registrationDataSet.tblCourses);
            }
            catch(Exception ex) // if get error trying to read table from database, show user error
            {
                MessageBox.Show(ex.Message, "Error");
            }

            //updates status bar or mainform
            SetReadyLabel("Courses form ready for use");

        }

        //Close the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
