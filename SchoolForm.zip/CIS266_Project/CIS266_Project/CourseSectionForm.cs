﻿//Jesse Clem
//Homework 5
//5/15/2018
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS266_Project
{
    public partial class CourseSectionForm : Form
    {
        public CourseSectionForm()
        {
            InitializeComponent();
        }

        private void tblCoursesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tblCoursesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.registrationDataSet);

        }

        private void tblCoursesBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.tblCoursesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.registrationDataSet);

        }

        private void tblSectionsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tblSectionsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.registrationDataSet);

        }

        private void tblCoursesBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.tblCoursesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.registrationDataSet);

        }

        private void CourseSectionForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registrationDataSet.tblSections' table. You can move, or remove it, as needed.
            this.tblSectionsTableAdapter.Fill(this.registrationDataSet.tblSections);
            // TODO: This line of code loads data into the 'registrationDataSet.tblCourses' table. You can move, or remove it, as needed.
            this.tblCoursesTableAdapter.Fill(this.registrationDataSet.tblCourses);

        }
    }
}
