﻿CREATE TABLE [dbo].[tblCourses]
(
	[crs_autCourseID] INT NOT NULL PRIMARY KEY,
	[crs_txtDept] TEXT NOT NULL, 
    [crs_txtNumber] TEXT NOT NULL, 
    [crs_txtTitle] TEXT NOT NULL, 
    [crs_bytCredits] INT NOT NULL,

)
