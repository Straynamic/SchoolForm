﻿CREATE TABLE [dbo].[tblEnrollments]
(
	[enr_intStudent] INT NOT NULL PRIMARY KEY, 
    [enr_lngSection] INT NOT NULL
)
