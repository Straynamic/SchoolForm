﻿//5/25/2018 Jesse Clem Homework 6

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS266_Project
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            dsRegistration = new RegistrationDataSet(); // instantiate dataset
        }

        // form dataset and property for access
        private RegistrationDataSet dsRegistration;
        public RegistrationDataSet GetRegistration
        {
            get
            {
                return dsRegistration;
            }
        }

        private void GetData()
        {
            //create table adapters to read db
            RegistrationDataSetTableAdapters.tblCoursesTableAdapter taCourses =
                new RegistrationDataSetTableAdapters.tblCoursesTableAdapter();
            RegistrationDataSetTableAdapters.tblEnrollmentsTableAdapter taEnrollments =
                new RegistrationDataSetTableAdapters.tblEnrollmentsTableAdapter();
            RegistrationDataSetTableAdapters.tblSectionsTableAdapter taSections =
                new RegistrationDataSetTableAdapters.tblSectionsTableAdapter();
            RegistrationDataSetTableAdapters.tblStudentsTableAdapter taStudents =
                new RegistrationDataSetTableAdapters.tblStudentsTableAdapter();

            try
            {
                //get data for each table
                taCourses.Fill(GetRegistration.tblCourses);
                taEnrollments.Fill(GetRegistration.tblEnrollments);
                taSections.Fill(GetRegistration.tblSections);
                taStudents.Fill(GetRegistration.tblStudents);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message); //put info about error where we can see
            }

        }

        private void SaveData()
        {
            //create table adapeters
            RegistrationDataSetTableAdapters.tblCoursesTableAdapter taCourses =
                new RegistrationDataSetTableAdapters.tblCoursesTableAdapter();
            RegistrationDataSetTableAdapters.tblEnrollmentsTableAdapter taEnrollments =
                new RegistrationDataSetTableAdapters.tblEnrollmentsTableAdapter();
            RegistrationDataSetTableAdapters.tblSectionsTableAdapter taSections =
                new RegistrationDataSetTableAdapters.tblSectionsTableAdapter();
            RegistrationDataSetTableAdapters.tblStudentsTableAdapter taStudents =
                new RegistrationDataSetTableAdapters.tblStudentsTableAdapter();
            //set up table adapter manager
            RegistrationDataSetTableAdapters.TableAdapterManager taManager =
                new RegistrationDataSetTableAdapters.TableAdapterManager();
            taManager.tblCoursesTableAdapter = taCourses;
            taManager.tblEnrollmentsTableAdapter = taEnrollments;
            taManager.tblSectionsTableAdapter = taSections;
            taManager.tblStudentsTableAdapter = taStudents;

            try
            {
                //write data to database
                taManager.UpdateAll(GetRegistration);
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message); //put info about error where we can see
            }

        }

        // provide access to ready label in status bar for
        // child forms
        public string ReadyLabel
        {
            set
            {
                tslReady.Text = value;
            }
        }

        private void ShowForm(Form formToShow)
        {
            formToShow.MdiParent = this;
            formToShow.Show();
        }

        //Shows the courses form
        private void coursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new Courses());
        }

        //Shows the schedules form
        private void sectionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new Schedules());
        }

        //Sets ready label on form load
        private void MainForm_Load(object sender, EventArgs e)
        {
            GetData();
            ReadyLabel = "Ready";
        }

        //Closes the form
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Changes display of all forms in the MDI to Cascade
        private void cascadeFormsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        //Changes display of all forms in the MDI to Horizontal
        private void tileFormsHorizontallyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        //Changes display of all forms in the MDI to Vertical
        private void tileFormsVerticallyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        //Closes all open forms in the MDI window
        private void closeAllWindowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form form in this.MdiChildren)
            {
                form.Close();
            }
        }

        //Shows the CourseSection form
        private void courseSectionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new CourseSectionForm());
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // if there's data not in db, ask user if should save
            if (GetRegistration.HasChanges())
            {
                DialogResult result = MessageBox.Show("Save changes?", "Unsaved Data", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    SaveData();
                }
            }
        }

        //Save all changed data
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        //Open StudentssForm window
        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentsForm sForm = new StudentsForm(GetRegistration);
            sForm.MdiParent = this;
            sForm.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
