﻿//5/25/2018 Jesse Clem Homework 6
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS266_Project
{
    public enum Editing
    { Adding, Updating, Displaying }

    public partial class StudentsForm : Form
    {
        public StudentsForm(RegistrationDataSet data)
        {
            InitializeComponent();
            registrationData = data;
            //students = registrationData.tblStudents;
            editState = Editing.Displaying;
        }

        private RegistrationDataSet registrationData;
        private Editing editState;

        // Form reference to retrieve data
        private RegistrationDataSet.tblStudentsDataTable Students
        {
            get
            {
                return registrationData.tblStudents;
            }
        }

        //Sets textbox text to the selected row from tblStudents
        private void ShowData(int Position)
        {

            RegistrationDataSet.tblStudentsRow row =
                (RegistrationDataSet.tblStudentsRow)Students.Rows[Position];
            txtStudentID.Text = row.stu_intStudentID.ToString();
            txtFirstName.Text = row.stu_txtFirstName.ToString();
            txtLastName.Text = row.stu_txtLastName.ToString();
        }

        //Keeps back of selected wow
        private int currentPosition;
        private int CurrentPosition
        {
            get
            {
                return currentPosition;
            }
            set
            {
                //If row is not negitive, and is less than existing row count
                if (value >= 0 && value < Students.Rows.Count)
                {
                    //update value
                    currentPosition = value;
                }
            }
        }

        //Show first entry
        private void MoveFirst()
        {
            CurrentPosition = 0;
            ShowData(CurrentPosition);
        }

        //Show last entry
        private void MoveLast()
        {
            CurrentPosition = Students.Rows.Count - 1;
            ShowData(CurrentPosition);
        }
        //Show previous entry
        private void MovePrevious()
        {
            CurrentPosition--;
            ShowData(CurrentPosition);
        }
        //Show next entry
        private void MoveNext()
        {
            CurrentPosition++;
            ShowData(CurrentPosition);
        }


        //Add entered data in textboxes to database
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //set up form for entry
            ClearForm();
            //disable buttons
            NavButtons(false);
            AddEditButtons(false);
            //enable entry controls
            LockControls(false);
            SaveCancelButtons(true);
            //set edit state
            editState = Editing.Adding;
        }

        //Edit selected data
        private void btnEdit_Click(object sender, EventArgs e)
        {
            //disable buttons
            NavButtons(false);
            AddEditButtons(false);
            //enable entry controls
            LockControls(false);
            SaveCancelButtons(true);
            //set edit state
            editState = Editing.Updating;
        }

        //Save selected data
        private void btnSave_Click(object sender, EventArgs e)
        {
            //if editing a row, assign values from controls to that row
            if (editState == Editing.Updating)
            {
                //get access to the active row
                RegistrationDataSet.tblStudentsRow sRow =
                    (RegistrationDataSet.tblStudentsRow)Students.Rows[CurrentPosition];
                //assign name to this row
                sRow.stu_txtFirstName = txtFirstName.Text;
                sRow.stu_txtLastName = txtLastName.Text;
            }
            else if (editState == Editing.Adding)
            {
                //need new row
                RegistrationDataSet.tblStudentsRow newStudentRow =
                    Students.NewtblStudentsRow();
                //assign values from controls to new row
                //newStudentRow.stu_intStudentID = txtStudentID.Text;
                newStudentRow.stu_txtFirstName = txtFirstName.Text;
                newStudentRow.stu_txtLastName = txtLastName.Text;
                //add to table
                Students.Rows.Add(newStudentRow);
                CurrentPosition = Students.Rows.Count - 1;
            }
            //update form for use
            NavButtons(true);
            AddEditButtons(true);
            LockControls(true);
            SaveCancelButtons(false);
            //done editing
            editState = Editing.Displaying;
        }

        //Delete seleccted data
        private void btnDelete_Click(object sender, EventArgs e)
        {
            //need new row
            RegistrationDataSet.tblStudentsRow newStudentRow =
                (RegistrationDataSet.tblStudentsRow)Students.Rows[CurrentPosition];
            //remove entry
            Students.Rows.Remove(newStudentRow);

            //update form for use
            NavButtons(true);
            AddEditButtons(true);
            LockControls(true);
            SaveCancelButtons(false);
            //done editing
            editState = Editing.Displaying;

            //Update display
            MovePrevious();

        }

        //Cancel editing selected data
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //if there's data
            if (IsThereData())
            {
                //show data from row previously shown
                ShowData(CurrentPosition);
                //enable controls
                NavButtons(true);
                AddEditButtons(true);
                //disable controls
                LockControls(true);
                SaveCancelButtons(false);
                //set edit state
                editState = Editing.Displaying;
            }
            else // empty table
            {
                //enable controls
                btnAdd.Enabled = true;
                //disable controls
                SaveCancelButtons(false);
                LockControls(true);
                //clear form
                ClearForm();
                //set edit state
                editState = Editing.Displaying;
            }

        }

        //Close the form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            MoveLast();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            MoveNext();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            MovePrevious();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            MoveFirst();
        }

        //Checks if there is data in the table. Return true / false
        private bool IsThereData()
        {
            return Students.Rows.Count > 0;
        }

        //Lock selected controls
        private void LockControls(bool locked)
        {
            txtFirstName.ReadOnly = locked;
            txtLastName.ReadOnly = locked;
        }

        private void ClearForm()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtStudentID.Clear();
        }

        private void NavButtons(bool enabled)
        {
            btnFirst.Enabled = enabled;
            btnPrevious.Enabled = enabled;
            btnNext.Enabled = enabled;
            btnLast.Enabled = enabled;
        }

        private void SaveCancelButtons(bool enabled)
        {
            btnSave.Enabled = enabled;
            btnCancel.Enabled = enabled;
        }

        private void AddEditButtons(bool enabled)
        {
            btnAdd.Enabled = enabled;
            btnEdit.Enabled = enabled;
        }

        private void StudentsForm_Load(object sender, EventArgs e)
        {
            AddEditButtons(true);

            //if there's data, show first row; if now, disable controls
            if (IsThereData())
            {
                MoveFirst();
                NavButtons(true);
                SaveCancelButtons(false);
            }
            else
            {
                NavButtons(false);
                SaveCancelButtons(false);
                btnEdit.Enabled = false;
            }
        }
    }
}
