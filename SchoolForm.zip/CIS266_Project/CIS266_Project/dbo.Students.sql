﻿CREATE TABLE [dbo].[tblStudents]
(
	[stu_txtStudentID] INT IDENTITY NOT NULL
	CONSTRAINT pk_Students PRIMARY KEY, 
    [stu_txtFirstName] TEXT NOT NULL, 
    [stu_txtLastName] TEXT NOT NULL

)
