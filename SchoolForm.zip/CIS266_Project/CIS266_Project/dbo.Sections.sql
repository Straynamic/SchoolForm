﻿CREATE TABLE [dbo].[tblSections]
(
	[sec_autSectionId] INT IDENTITY NOT NULL
		CONSTRAINT pk_Section PRIMARY KEY, 
    [sec_txtQuarter] NCHAR(20) NOT NULL, 
    [sec_txtItem] NCHAR(20) NOT NULL, 
    [sec_lngCourse] INT NOT NULL, 
    [sec_txtDays] NCHAR(30) NOT NULL, 
    [sec_dtmStart] DATETIME NOT NULL, 
    [sec_dtmEnd] DATETIME NOT NULL, 
    [sec_txtRoom] NCHAR(10) NOT NULL, 
    [sec_txtInstructor] NCHAR(25) NOT NULL
)
