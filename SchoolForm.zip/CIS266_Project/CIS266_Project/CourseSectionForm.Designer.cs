﻿namespace CIS266_Project
{
    partial class CourseSectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CourseSectionForm));
            System.Windows.Forms.Label crs_autCourseIDLabel;
            System.Windows.Forms.Label crs_txtDeptLabel;
            System.Windows.Forms.Label crs_txtNumberLabel;
            System.Windows.Forms.Label crs_txtTitleLabel;
            System.Windows.Forms.Label crs_bytCreditsLabel;
            this.registrationDataSet = new CIS266_Project.RegistrationDataSet();
            this.tblCoursesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblCoursesTableAdapter = new CIS266_Project.RegistrationDataSetTableAdapters.tblCoursesTableAdapter();
            this.tableAdapterManager = new CIS266_Project.RegistrationDataSetTableAdapters.TableAdapterManager();
            this.tblCoursesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tblCoursesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.crs_autCourseIDLabel1 = new System.Windows.Forms.Label();
            this.crs_txtDeptTextBox = new System.Windows.Forms.TextBox();
            this.crs_txtNumberTextBox = new System.Windows.Forms.TextBox();
            this.crs_txtTitleTextBox = new System.Windows.Forms.TextBox();
            this.crs_bytCreditsTextBox = new System.Windows.Forms.TextBox();
            this.tblSectionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblSectionsTableAdapter = new CIS266_Project.RegistrationDataSetTableAdapters.tblSectionsTableAdapter();
            this.tblSectionsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            crs_autCourseIDLabel = new System.Windows.Forms.Label();
            crs_txtDeptLabel = new System.Windows.Forms.Label();
            crs_txtNumberLabel = new System.Windows.Forms.Label();
            crs_txtTitleLabel = new System.Windows.Forms.Label();
            crs_bytCreditsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.registrationDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCoursesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCoursesBindingNavigator)).BeginInit();
            this.tblCoursesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // registrationDataSet
            // 
            this.registrationDataSet.DataSetName = "RegistrationDataSet";
            this.registrationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblCoursesBindingSource
            // 
            this.tblCoursesBindingSource.DataMember = "tblCourses";
            this.tblCoursesBindingSource.DataSource = this.registrationDataSet;
            // 
            // tblCoursesTableAdapter
            // 
            this.tblCoursesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tblCoursesTableAdapter = this.tblCoursesTableAdapter;
            this.tableAdapterManager.tblEnrollmentsTableAdapter = null;
            this.tableAdapterManager.tblSectionsTableAdapter = this.tblSectionsTableAdapter;
            this.tableAdapterManager.tblStudentsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = CIS266_Project.RegistrationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tblCoursesBindingNavigator
            // 
            this.tblCoursesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tblCoursesBindingNavigator.BindingSource = this.tblCoursesBindingSource;
            this.tblCoursesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tblCoursesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tblCoursesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tblCoursesBindingNavigatorSaveItem});
            this.tblCoursesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tblCoursesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tblCoursesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tblCoursesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tblCoursesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tblCoursesBindingNavigator.Name = "tblCoursesBindingNavigator";
            this.tblCoursesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tblCoursesBindingNavigator.Size = new System.Drawing.Size(654, 25);
            this.tblCoursesBindingNavigator.TabIndex = 0;
            this.tblCoursesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // tblCoursesBindingNavigatorSaveItem
            // 
            this.tblCoursesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tblCoursesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tblCoursesBindingNavigatorSaveItem.Image")));
            this.tblCoursesBindingNavigatorSaveItem.Name = "tblCoursesBindingNavigatorSaveItem";
            this.tblCoursesBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.tblCoursesBindingNavigatorSaveItem.Text = "Save Data";
            this.tblCoursesBindingNavigatorSaveItem.Click += new System.EventHandler(this.tblCoursesBindingNavigatorSaveItem_Click_2);
            // 
            // crs_autCourseIDLabel
            // 
            crs_autCourseIDLabel.AutoSize = true;
            crs_autCourseIDLabel.Location = new System.Drawing.Point(29, 31);
            crs_autCourseIDLabel.Name = "crs_autCourseIDLabel";
            crs_autCourseIDLabel.Size = new System.Drawing.Size(60, 13);
            crs_autCourseIDLabel.TabIndex = 1;
            crs_autCourseIDLabel.Text = " Course ID:";
            // 
            // crs_autCourseIDLabel1
            // 
            this.crs_autCourseIDLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCoursesBindingSource, "crs_autCourseID", true));
            this.crs_autCourseIDLabel1.Location = new System.Drawing.Point(127, 31);
            this.crs_autCourseIDLabel1.Name = "crs_autCourseIDLabel1";
            this.crs_autCourseIDLabel1.Size = new System.Drawing.Size(100, 23);
            this.crs_autCourseIDLabel1.TabIndex = 2;
            this.crs_autCourseIDLabel1.Text = "label1";
            // 
            // crs_txtDeptLabel
            // 
            crs_txtDeptLabel.AutoSize = true;
            crs_txtDeptLabel.Location = new System.Drawing.Point(29, 60);
            crs_txtDeptLabel.Name = "crs_txtDeptLabel";
            crs_txtDeptLabel.Size = new System.Drawing.Size(33, 13);
            crs_txtDeptLabel.TabIndex = 3;
            crs_txtDeptLabel.Text = "Dept:";
            // 
            // crs_txtDeptTextBox
            // 
            this.crs_txtDeptTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCoursesBindingSource, "crs_txtDept", true));
            this.crs_txtDeptTextBox.Location = new System.Drawing.Point(127, 57);
            this.crs_txtDeptTextBox.Name = "crs_txtDeptTextBox";
            this.crs_txtDeptTextBox.Size = new System.Drawing.Size(100, 20);
            this.crs_txtDeptTextBox.TabIndex = 4;
            // 
            // crs_txtNumberLabel
            // 
            crs_txtNumberLabel.AutoSize = true;
            crs_txtNumberLabel.Location = new System.Drawing.Point(29, 86);
            crs_txtNumberLabel.Name = "crs_txtNumberLabel";
            crs_txtNumberLabel.Size = new System.Drawing.Size(47, 13);
            crs_txtNumberLabel.TabIndex = 5;
            crs_txtNumberLabel.Text = "Number:";
            // 
            // crs_txtNumberTextBox
            // 
            this.crs_txtNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCoursesBindingSource, "crs_txtNumber", true));
            this.crs_txtNumberTextBox.Location = new System.Drawing.Point(127, 83);
            this.crs_txtNumberTextBox.Name = "crs_txtNumberTextBox";
            this.crs_txtNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.crs_txtNumberTextBox.TabIndex = 6;
            // 
            // crs_txtTitleLabel
            // 
            crs_txtTitleLabel.AutoSize = true;
            crs_txtTitleLabel.Location = new System.Drawing.Point(29, 112);
            crs_txtTitleLabel.Name = "crs_txtTitleLabel";
            crs_txtTitleLabel.Size = new System.Drawing.Size(30, 13);
            crs_txtTitleLabel.TabIndex = 7;
            crs_txtTitleLabel.Text = "Title:";
            // 
            // crs_txtTitleTextBox
            // 
            this.crs_txtTitleTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCoursesBindingSource, "crs_txtTitle", true));
            this.crs_txtTitleTextBox.Location = new System.Drawing.Point(127, 109);
            this.crs_txtTitleTextBox.Name = "crs_txtTitleTextBox";
            this.crs_txtTitleTextBox.Size = new System.Drawing.Size(100, 20);
            this.crs_txtTitleTextBox.TabIndex = 8;
            // 
            // crs_bytCreditsLabel
            // 
            crs_bytCreditsLabel.AutoSize = true;
            crs_bytCreditsLabel.Location = new System.Drawing.Point(29, 138);
            crs_bytCreditsLabel.Name = "crs_bytCreditsLabel";
            crs_bytCreditsLabel.Size = new System.Drawing.Size(42, 13);
            crs_bytCreditsLabel.TabIndex = 9;
            crs_bytCreditsLabel.Text = "Credits:";
            // 
            // crs_bytCreditsTextBox
            // 
            this.crs_bytCreditsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tblCoursesBindingSource, "crs_bytCredits", true));
            this.crs_bytCreditsTextBox.Location = new System.Drawing.Point(127, 135);
            this.crs_bytCreditsTextBox.Name = "crs_bytCreditsTextBox";
            this.crs_bytCreditsTextBox.Size = new System.Drawing.Size(100, 20);
            this.crs_bytCreditsTextBox.TabIndex = 10;
            // 
            // tblSectionsBindingSource
            // 
            this.tblSectionsBindingSource.DataMember = "tblCourses_tblSections";
            this.tblSectionsBindingSource.DataSource = this.tblCoursesBindingSource;
            // 
            // tblSectionsTableAdapter
            // 
            this.tblSectionsTableAdapter.ClearBeforeFill = true;
            // 
            // tblSectionsDataGridView
            // 
            this.tblSectionsDataGridView.AutoGenerateColumns = false;
            this.tblSectionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblSectionsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.tblSectionsDataGridView.DataSource = this.tblSectionsBindingSource;
            this.tblSectionsDataGridView.Location = new System.Drawing.Point(23, 171);
            this.tblSectionsDataGridView.Name = "tblSectionsDataGridView";
            this.tblSectionsDataGridView.Size = new System.Drawing.Size(609, 182);
            this.tblSectionsDataGridView.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "sec_autSectionId";
            this.dataGridViewTextBoxColumn1.HeaderText = "sec_autSectionId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "sec_txtQuarter";
            this.dataGridViewTextBoxColumn2.HeaderText = "sec_txtQuarter";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "sec_txtItem";
            this.dataGridViewTextBoxColumn3.HeaderText = "sec_txtItem";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "sec_lngCourse";
            this.dataGridViewTextBoxColumn4.HeaderText = "sec_lngCourse";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "sec_txtDays";
            this.dataGridViewTextBoxColumn5.HeaderText = "sec_txtDays";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "sec_dtmStart";
            this.dataGridViewTextBoxColumn6.HeaderText = "sec_dtmStart";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "sec_dtmEnd";
            this.dataGridViewTextBoxColumn7.HeaderText = "sec_dtmEnd";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "sec_txtRoom";
            this.dataGridViewTextBoxColumn8.HeaderText = "sec_txtRoom";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "sec_txtInstructor";
            this.dataGridViewTextBoxColumn9.HeaderText = "sec_txtInstructor";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // CourseSectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 371);
            this.Controls.Add(this.tblSectionsDataGridView);
            this.Controls.Add(crs_autCourseIDLabel);
            this.Controls.Add(this.crs_autCourseIDLabel1);
            this.Controls.Add(crs_txtDeptLabel);
            this.Controls.Add(this.crs_txtDeptTextBox);
            this.Controls.Add(crs_txtNumberLabel);
            this.Controls.Add(this.crs_txtNumberTextBox);
            this.Controls.Add(crs_txtTitleLabel);
            this.Controls.Add(this.crs_txtTitleTextBox);
            this.Controls.Add(crs_bytCreditsLabel);
            this.Controls.Add(this.crs_bytCreditsTextBox);
            this.Controls.Add(this.tblCoursesBindingNavigator);
            this.Name = "CourseSectionForm";
            this.Text = "CourseSectionForm";
            this.Load += new System.EventHandler(this.CourseSectionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.registrationDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCoursesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCoursesBindingNavigator)).EndInit();
            this.tblCoursesBindingNavigator.ResumeLayout(false);
            this.tblCoursesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RegistrationDataSet registrationDataSet;
        private System.Windows.Forms.BindingSource tblCoursesBindingSource;
        private RegistrationDataSetTableAdapters.tblCoursesTableAdapter tblCoursesTableAdapter;
        private RegistrationDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tblCoursesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tblCoursesBindingNavigatorSaveItem;
        private RegistrationDataSetTableAdapters.tblSectionsTableAdapter tblSectionsTableAdapter;
        private System.Windows.Forms.Label crs_autCourseIDLabel1;
        private System.Windows.Forms.TextBox crs_txtDeptTextBox;
        private System.Windows.Forms.TextBox crs_txtNumberTextBox;
        private System.Windows.Forms.TextBox crs_txtTitleTextBox;
        private System.Windows.Forms.TextBox crs_bytCreditsTextBox;
        private System.Windows.Forms.BindingSource tblSectionsBindingSource;
        private System.Windows.Forms.DataGridView tblSectionsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}